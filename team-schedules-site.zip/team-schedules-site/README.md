# Team Schedule Sync (daily-updating website)

A website where you pick teams from the top five European soccer leagues, the NBA and the NFL and add their games to Google Calendar. GitHub rebuilds it every morning with fresh schedules, so you never have to update anything by hand.

## What's in this folder

| Path | What it is |
| --- | --- |
| `site/index.html` | The website |
| `site/data.json` | The schedule data. Starts with the schedules from Nov 5-7, then GitHub replaces it every day |
| `scripts/fetch_schedules.py` | Pulls fresh schedules from ESPN and rewrites `data.json` |
| `scripts/test_fetch.py` | Offline checks of the script's logic (optional) |
| `.github/workflows/update.yml` | The daily job. It's a hidden folder on some computers, so a visible copy is in `workflow-file/` |

## Setup (about 10 minutes, one time)

You need a free GitHub account (<https://github.com/signup>).

### 1. Create the repository
1. Sign in to GitHub, click **+** (top right) → **New repository**.
2. Name it `team-schedules`.
3. Choose **Public**. Free GitHub accounts can only publish a website from a public repository. The repository holds only schedule data and the site code, nothing private.
4. Leave everything else unticked and click **Create repository**.

### 2. Upload the files
1. Unzip the file you downloaded.
2. On the new empty repository page, click **uploading an existing file**.
3. Open the unzipped folder and drag in everything inside it: `site`, `scripts`, `workflow-file` and `README.md`. Drag the contents, not the zip.
4. Click **Commit changes**.

### 3. Add the daily job
The job file lives in a hidden folder that drag-and-drop often skips, so add it by hand:
1. In the repository click **Add file** → **Create new file**.
2. In the name box type `.github/workflows/update.yml`. Typing the slashes creates the folders.
3. Open `workflow-file/update.yml` from the unzipped folder in any text editor, copy everything and paste it into the big box on GitHub.
4. Click **Commit changes** → **Commit changes**.

### 4. Turn on the website
1. In the repository click **Settings** → **Pages** (left menu).
2. Under **Build and deployment**, set **Source** to **GitHub Actions**.

### 5. Run it once
1. Click the **Actions** tab → **Update schedules and deploy** → **Run workflow** → **Run workflow**.
2. Wait about 2 to 4 minutes for a green check. If your first commit already started a run that shows a red X at the Pages step, that is only because Pages was not on yet. Run it again.
3. Your site is at `https://YOUR-GITHUB-USERNAME.github.io/team-schedules/`. The run summary also shows the link.

From now on it updates itself every day at about 4:23 AM US Eastern (5:23 AM in summer).

## Check that the daily update works
Open the run on the Actions tab → **update-and-deploy** → **Refresh schedules**. A good run prints one line per league, for example `Premier League: 20 teams, 96 upcoming games`, and ends with `Wrote ... games for 158 teams`.

On the website, the footer line says "Updated" with the date of the last successful refresh.

## If something goes wrong
- **"could not refresh <league>" in the log.** The site keeps that league's previous data and the other leagues still update. ESPN's feed is unofficial and can change or have an off day. If it keeps happening, copy the log text and send it to me.
- **The site still says "Updated Nov 5" after a run.** The refresh step failed for every league and the site is showing the starting data. Open the **Refresh schedules** step and read the message.
- **Red X at "Save updated data" with a permissions message.** Go to Settings → Actions → General → Workflow permissions, choose **Read and write permissions**, save, and run it again.
- **Scheduled runs stopped.** GitHub pauses scheduled jobs in repositories with no activity for 60 days. If it happens, the Actions tab shows an **Enable** button.

## Notes
- The refresh script has only been tested against sample data, not against ESPN's live feed, so the first real run is the real test.
- Covered: domestic league games only. Champions League, Europa League, cup and international games are not included.
- To change the daily time, edit the `cron` line in `.github/workflows/update.yml`. The time is in UTC.
- Your selected teams are saved in your own browser.
