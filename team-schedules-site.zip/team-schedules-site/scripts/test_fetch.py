"""Offline checks for fetch_schedules.py. Run: python scripts/test_fetch.py"""
import json
import os
import tempfile
from datetime import datetime, timezone

import fetch_schedules as fs

fs.PAUSE = 0
NOW = datetime(2026, 11, 7, 12, 0, tzinfo=timezone.utc)


def ev(eid, date, home, away, state="pre", name="STATUS_SCHEDULED", time_valid=True, notes=None):
    comp = {
        "competitors": [
            {"homeAway": "home", "team": {"id": home[0], "displayName": home[1]}},
            {"homeAway": "away", "team": {"id": away[0], "displayName": away[1]}},
        ],
        "status": {"type": {"state": state, "name": name}},
    }
    if notes:
        comp["notes"] = notes
    return {"id": eid, "date": date, "timeValid": time_valid, "competitions": [comp]}


A, B, C = ("1", "Alpha FC"), ("2", "Beta FC"), ("3", "Gamma FC")


def test_parse_event():
    ok = fs.parse_event(ev("10", "2026-11-08T20:00Z", A, B))
    assert ok == ("10", "2026-11-08T20:00:00+00:00", A, B, "scheduled", ""), ok
    assert fs.parse_event(ev("11", "2026-11-08T20:00Z", A, B, state="post")) is None
    assert fs.parse_event(ev("12", "2026-11-08T20:00Z", A, B, name="STATUS_POSTPONED")) is None
    assert fs.parse_event(ev("13", "2026-11-08T20:00Z", A, B, time_valid=False))[4] == "flex-schedule"
    n = fs.parse_event(ev("14", "2026-11-08T20:00Z", A, B, notes=[{"headline": "Thursday Night Football"}]))
    assert n[5] == "Thursday Night Football"
    bad = ev("15", "2026-11-08T20:00Z", A, B)
    bad["competitions"][0]["competitors"].pop()
    assert fs.parse_event(bad) is None


def test_team_list():
    data = {"sports": [{"leagues": [{"teams": [{"team": {"id": "1", "displayName": "Alpha FC"}},
                                              {"team": {"id": "2", "displayName": "Beta FC"}}]}]}]}
    assert fs.parse_team_list(data) == {"1": "Alpha FC", "2": "Beta FC"}
    assert fs.parse_team_list({}) == {}


def test_refresh_league():
    lg = {"id": "demo", "label": "Demo", "path": "x/y", "sched": ["?a=1"]}
    team_list = {"sports": [{"leagues": [{"teams": [{"team": {"id": "1", "displayName": "Alpha FC"}},
                                                  {"team": {"id": "2", "displayName": "Beta FC"}}]}]}]}
    shared = ev("20", "2026-11-09T20:00Z", A, B)
    schedules = {
        "1": {"events": [shared, ev("21", "2026-11-12T20:00Z", C, A), ev("22", "2026-11-01T20:00Z", A, B)]},
        "2": {"events": [shared]},
    }

    def fake(url, tries=3):
        if url.endswith("/teams?limit=100"):
            return team_list
        tid = url.split("/teams/")[1].split("/")[0]
        return schedules[tid]

    real = fs.fetch_json
    fs.fetch_json = fake
    try:
        teams, games = fs.refresh_league(lg, NOW)
    finally:
        fs.fetch_json = real
    ids = sorted(g[1] for g in games)
    assert ids == ["20", "21"], ids  # shared game once; old game (Nov 1) dropped
    assert teams["demo:1"] == ["Alpha FC", "demo", 1]
    assert teams["demo:3"] == ["Gamma FC", "demo", 0]  # opponent not in team list: not selectable
    row = next(g for g in games if g[1] == "21")
    assert row[3] == "demo:3" and row[4] == "demo:1"


def test_keep_previous_on_failure():
    tmp = tempfile.mkdtemp()
    out = os.path.join(tmp, "data.json")
    prev = {"asof": "2026-11-01", "leagues": [], "teams": {"epl:9": ["Old FC", "epl", 1], "nba:5": ["Old Team", "nba", 1]},
            "games": [["epl", "1", "2026-12-01T20:00:00+00:00", "epl:9", "epl:9", "scheduled", ""]]}
    json.dump(prev, open(out, "w"))
    fs.OUT = out
    fs.LEAGUES = [
        {"id": "epl", "label": "Premier League", "path": "p/e", "sched": [""]},
        {"id": "nba", "label": "NBA", "path": "p/n", "sched": [""]},
    ]
    team_list = {"sports": [{"leagues": [{"teams": [{"team": {"id": "5", "displayName": "New Team"}}]}]}]}

    def fake(url, tries=3):
        if "p/e" in url:
            raise RuntimeError("feed down")
        if url.endswith("/teams?limit=100"):
            return team_list
        return {"events": [ev("30", "2026-12-05T20:00Z", ("5", "New Team"), ("6", "Other"))]}

    real = fs.fetch_json
    fs.fetch_json = fake
    try:
        fs.main()
    finally:
        fs.fetch_json = real
    data = json.load(open(out))
    assert any(g[0] == "epl" and g[1] == "1" for g in data["games"]), "previous epl games should be kept"
    assert any(g[0] == "nba" and g[1] == "30" for g in data["games"]), "nba should be refreshed"
    assert "epl:9" in data["teams"] and "nba:5" in data["teams"]


if __name__ == "__main__":
    test_parse_event()
    test_team_list()
    test_refresh_league()
    test_keep_previous_on_failure()
    print("all checks passed")
