#!/usr/bin/env python3
"""Refresh site/data.json from ESPN's public schedule feed.

For every league it:
  1. loads the team list,
  2. loads each team's schedule,
  3. keeps games that have not started yet and removes postponed or cancelled ones,
  4. writes everything to site/data.json, which the website reads.

If a league cannot be loaded (feed down, empty answer), the previous data for that league
is kept, so one bad day never empties the site. The script exits with an error only when
no league could be refreshed at all.
"""
import json
import os
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone

BASE = "https://site.api.espn.com/apis/site/v2/sports"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "site", "data.json")

# "sched" lists the schedule URL suffixes to read for each team; results are merged.
LEAGUES = [
    {"id": "epl",        "label": "Premier League", "path": "soccer/eng.1",     "sched": ["?fixture=true"]},
    {"id": "laliga",     "label": "La Liga",        "path": "soccer/esp.1",     "sched": ["?fixture=true"]},
    {"id": "seriea",     "label": "Serie A",        "path": "soccer/ita.1",     "sched": ["?fixture=true"]},
    {"id": "bundesliga", "label": "Bundesliga",     "path": "soccer/ger.1",     "sched": ["?fixture=true"]},
    {"id": "ligue1",     "label": "Ligue 1",        "path": "soccer/fra.1",     "sched": ["?fixture=true"]},
    {"id": "nba",        "label": "NBA",            "path": "basketball/nba",   "sched": ["?seasontype=2", "?seasontype=3"]},
    {"id": "nfl",        "label": "NFL",            "path": "football/nfl",     "sched": ["?seasontype=2", "?seasontype=3"]},
]

SKIP_WORDS = ("POSTPONED", "CANCEL", "SUSPEND", "DELAY", "ABANDON")
PAUSE = 0.25  # seconds between requests, to be polite to the feed


def fetch_json(url, tries=3):
    last = None
    for attempt in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "team-schedule-sync/1.0"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.load(resp)
        except urllib.error.HTTPError as exc:
            last = exc
            if exc.code in (400, 404):  # not retryable, e.g. no playoff schedule yet
                break
            time.sleep(2 * (attempt + 1))
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            last = exc
            time.sleep(2 * (attempt + 1))
    raise RuntimeError(f"{url}: {last}")


def to_iso(text):
    """ESPN dates look like 2026-11-07T20:00Z. Return 2026-11-07T20:00:00+00:00."""
    d = datetime.fromisoformat(text.replace("Z", "+00:00"))
    if d.tzinfo is None:
        d = d.replace(tzinfo=timezone.utc)
    return d.astimezone(timezone.utc).isoformat(timespec="seconds")


def parse_team_list(data):
    teams = {}
    try:
        items = data["sports"][0]["leagues"][0]["teams"]
    except (KeyError, IndexError, TypeError):
        return teams
    for item in items:
        t = item.get("team") or {}
        if t.get("id") and t.get("displayName"):
            teams[str(t["id"])] = t["displayName"]
    return teams


def parse_event(ev):
    """Return (event_id, start_iso, home_team, away_team, status, note) or None.

    home_team / away_team are (espn_team_id, display_name) tuples.
    """
    comp = (ev.get("competitions") or [{}])[0]
    status = ((comp.get("status") or ev.get("status") or {}).get("type")) or {}
    if status.get("state") != "pre":
        return None
    if any(w in str(status.get("name", "")).upper() for w in SKIP_WORDS):
        return None
    home = away = None
    for c in comp.get("competitors") or []:
        if c.get("homeAway") == "home":
            home = c
        elif c.get("homeAway") == "away":
            away = c
    if not home or not away:
        return None
    ht, at = home.get("team") or {}, away.get("team") or {}
    if not ht.get("id") or not at.get("id"):
        return None
    raw_date = ev.get("date") or comp.get("date")
    if not raw_date or not ev.get("id"):
        return None
    tbc = ev.get("timeValid") is False or comp.get("timeValid") is False
    note = ""
    for n in (comp.get("notes") or ev.get("notes") or []):
        if isinstance(n, dict) and n.get("headline"):
            note = str(n["headline"])
            break
    return (
        str(ev["id"]), to_iso(raw_date),
        (str(ht["id"]), ht.get("displayName") or ht.get("name") or "TBD"),
        (str(at["id"]), at.get("displayName") or at.get("name") or "TBD"),
        "flex-schedule" if tbc else "scheduled", note,
    )


def refresh_league(lg, now):
    """Return (teams, games) for one league. Raises RuntimeError if nothing usable came back."""
    lid = lg["id"]
    teams_raw = parse_team_list(fetch_json(f"{BASE}/{lg['path']}/teams?limit=100"))
    if not teams_raw:
        raise RuntimeError("empty team list")
    teams = {f"{lid}:{tid}": [name, lid, 1] for tid, name in teams_raw.items()}
    games, errors = {}, 0
    cutoff = now - timedelta(hours=3)
    for tid in sorted(teams_raw):
        for suffix in lg["sched"]:
            time.sleep(PAUSE)
            try:
                data = fetch_json(f"{BASE}/{lg['path']}/teams/{tid}/schedule{suffix}")
            except RuntimeError:
                errors += 1
                continue
            for ev in data.get("events") or []:
                parsed = parse_event(ev)
                if not parsed:
                    continue
                eid, start, (hid, hname), (aid, aname), status, note = parsed
                if datetime.fromisoformat(start) < cutoff:
                    continue
                hk, ak = f"{lid}:{hid}", f"{lid}:{aid}"
                for key, name in ((hk, hname), (ak, aname)):
                    if key not in teams:
                        teams[key] = [name, lid, 0]  # known opponent, not selectable
                games.setdefault(eid, [lid, eid, start, hk, ak, status, note])
    if not games:
        raise RuntimeError(f"no upcoming games found ({errors} schedule requests failed)")
    print(f"  {lg['label']}: {len(teams_raw)} teams, {len(games)} upcoming games, {errors} failed requests")
    return teams, list(games.values())


def main():
    now = datetime.now(timezone.utc)
    prev = None
    if os.path.exists(OUT):
        try:
            prev = json.load(open(OUT, encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            prev = None

    teams, games, refreshed = {}, [], 0
    for lg in LEAGUES:
        print(f"Refreshing {lg['label']}...")
        try:
            t, g = refresh_league(lg, now)
            teams.update(t)
            games += g
            refreshed += 1
        except RuntimeError as exc:
            print(f"  could not refresh {lg['label']}: {exc}", file=sys.stderr)
            if prev:
                keep_t = {k: v for k, v in prev["teams"].items() if v[1] == lg["id"]}
                keep_g = [r for r in prev["games"] if r[0] == lg["id"]]
                teams.update(keep_t)
                games += keep_g
                print(f"  kept previous data for {lg['label']}: {len(keep_g)} games")

    if not refreshed:
        sys.exit("No league could be refreshed; leaving data.json unchanged.")

    games.sort(key=lambda r: (r[2], r[0], r[1]))
    blob = {
        "asof": now.strftime("%Y-%m-%d"),
        "leagues": [{"id": l["id"], "label": l["label"], "tok": l["id"]} for l in LEAGUES],
        "teams": teams,
        "games": games,
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump(blob, fh, ensure_ascii=False, separators=(",", ":"))
    print(f"Wrote {len(games)} games for {sum(1 for v in teams.values() if v[2])} teams ({refreshed}/{len(LEAGUES)} leagues refreshed).")


if __name__ == "__main__":
    main()
